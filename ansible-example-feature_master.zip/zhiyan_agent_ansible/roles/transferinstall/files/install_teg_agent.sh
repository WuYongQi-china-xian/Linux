#! /bin/bash

shell_current_path=$(cd "$( dirname "$( readlink "$0" || echo "$0" )" )"; pwd)
echo "当前shell脚本的存放目录为：$shell_current_path"

rpm_agent_name=$1

function install(){
    is_have_agent=$(rpm -qa | grep zhiyan-ajs-agent)
    if [[ -z $is_have_agent ]];then
        echo "没有agent，需要安装"
        rpm -ivh ${shell_current_path}/${rpm_agent_name};$ret
        if [[ $ret -eq 0 ]];then
            echo "安装agent成功"
            is_start_agent=$(ps -ef | grep -v grep | grep ajs_work_agent)
            if [[ -z $is_start_agent ]];then
                echo "agent启动失败"
                exit 1
            else
                echo "agent启动成功"
            fi
        else
            echo "安装agent失败"
            exit $ret
        fi
    else
        echo "有agent，不需要安装"
    fi
}

function main(){
   install
}

main