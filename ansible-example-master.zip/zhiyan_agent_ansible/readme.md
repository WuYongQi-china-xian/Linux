# 分支管理明细
- 主干分支只记录脚本的范本
- 其他开发分支复制test_env记录主机信息和临时密码供流水线使用进行批量操作

# 脚本使用方法
1. 复制test_env的文件为一个自定义文件与其同目录级别摆放，填写机器和密码信息
2. 查看all文件看是否需要修改默认的mirro_url、current_version_package变量的值
3. 如果使用transferinstall则需往roles\transferinstall\files下放置与2步骤current_version_package变量的值对应的rmp包
4. 命令行启动脚本：
   * 直接rpm镜像源安装： ansible-playbook -i 自定义文件名 main.yml --tags install
   * 直接rpm包安装： ansible-playbook -i 自定义文件名 main.yml --tags transferinstall

# 环境变量透传启动命令样例
- ansible-playbook -i test_env3 main.yml --tags transferinstall --extra-vars "install_user='root' install_pass='xxx' current_version_package='teg-devops-zhiyan-ajs-agent-0.0.5-1-x86_64.rpm'"
- ansible-playbook -i test_env3 main.yml --tags install --extra-vars "install_user='root' install_pass='xxx' mirro_url='http://mirrors.woa.com/repository/rpm/tencent_rpm/x86_64/teg-devops-zhiyan-ajs-agent-0.0.5-1-x86_64.rpm'"

## 脚本入参
- install_user：该脚本基于root用户操作开发，请保持使用root用户，如需要使用非root用户，请根据实际情况另立分支改写脚本
- install_pass：用户对于的ssh密码
- current_version_package： TEG agent包名
- mirro_url: TEG agent镜像源url

# 注意
- 流水线中的ssh端口为36000，不是默认的22
- root可以直连的机器可以直接使用此脚本
- 铁将军、星云管理的非root直连的机器，ansible 无法通过sudo提权去连接，只能手动安装